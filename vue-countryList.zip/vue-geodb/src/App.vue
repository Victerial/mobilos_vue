<script setup>
import Crud from './components/Crud.vue'
</script>

<template>
      <Crud />

</template>

<style scoped>

</style>
