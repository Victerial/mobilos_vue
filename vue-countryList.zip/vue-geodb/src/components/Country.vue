<script setup>
    import { defineProps, ref } from 'vue';
    import axios from 'axios';
    const props=defineProps({
        country:Object
    });
    const nameInput = ref("");
    let classPopUp = ref("popup-close");
    async function deleteCountry(){
        await axios.delete(`http://localhost:3000/country/${props.country.id}`);
        location.reload();
    }

    async function updateCountry(){
        await axios.put(`http://localhost:3000/country/${props.country.id}`,{
            name:nameInput.value
        });
        location.reload();
    }

    function openPopUp(){
        classPopUp.value = "popup-open";
    }

    function closePopUp(){
        classPopUp.value = "popup-close";
    }

    
</script>

<template>
    <div class="card">
        <div class="card-body">
            <h2>{{props.country.name}}</h2>
        </div>
        <div class="buttons">
            <button class="btn red" @click="deleteCountry">Törles</button>
            <button class="btn green" @click="openPopUp">Módosítás</button>
        </div>
    </div>
    <div :class="classPopUp">
        <div class="wrapper">
            <div>Név:</div>
            <input type="text" v-model="nameInput">
            <button class="btn green" @click="updateCountry">Módosítás</button>
            <button class="btn red" @click="closePopUp">Bezárás</button>
        </div>
    </div>
</template>

<style scoped>

.popup-close {
    display: none;
  }
  .popup-open {
    position: absolute;
    background-color: red;
    width: 100vw;
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .wrapper {
    display: flex;
    flex-direction: column;
    gap: 1rem;
    border: 1px solid black;
    padding: 2rem;
    max-width: 15rem;
    background-color: #3f3f46;
    border-radius: 1rem;
  }



    .card{
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        border: 1px solid black;
        padding: 2rem;
        max-width: 15rem;
        background-color: #3f3f46;
        border-radius: 1rem;
        gap: 1rem;
        max-height: 10rem;
    }

    .buttons{
        display: flex;
        gap: 1rem;
    }
    .btn{
        padding: .5rem;
        padding-left: 1rem;
        padding-right: 1rem;
        border: none;
        border-radius: .3rem;
        cursor: pointer;
    }
    .red{
        background-color: #dc2626;
    }
    .green{
        background-color: #22c55e;
    }

</style>