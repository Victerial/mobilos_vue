<script setup>
  import axios from 'axios'
  import {onMounted, ref} from 'vue'
  import Country from './Country.vue';

  const countries = ref([])
  let classPopUp = ref("popup-close");
  const nameInput = ref("");



  onMounted( async () => {
    let fetch = await axios.get("http://localhost:3000/country")
    countries.value = fetch.data
    console.log(fetch.data)
    console.log(countries.value)
    
  })
  async function addCountry(){
        await axios.post("http://localhost:3000/country",{
            name:nameInput.value
        })
        location.reload();

    }
  function openPopUp(){
        classPopUp.value = "popup-open";
    }

    function closePopUp(){
        classPopUp.value = "popup-close";
    }
</script>

<template>
  <div class="country-wrapper">
    <Country v-for="country in countries" :country="country" />

    <div :class="classPopUp">
        <div class="wrapper">
            <div>Név:</div>
            <input type="text" v-model="nameInput">
            <button class="btn green" @click="addCountry">Hozzáadás</button>
            <button class="btn red" @click="closePopUp">Bezárás</button>
        </div>
    </div>

    <button class="btn" @click="openPopUp">
      Hozzáadás
    </button>
  </div>

    
  

</template>

<style scoped>


.popup-close {
    display: none;
  }
  .popup-open {
    position: absolute;
    background-color: red;
    width: 100vw;
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .country-wrapper {
    display: flex;
    gap: 1.5rem;
    flex-wrap: wrap;
    width: 100%;
    height: 100%;
  }
  .wrapper {
    display: flex;
    flex-direction: column;
    gap: 1rem;
    border: 1px solid black;
    padding: 2rem;
    max-width: 15rem;
    background-color: #3f3f46;
    border-radius: 1rem;
  }
  
  .buttons{
        display: flex;
        gap: 1rem;
    }
    .btn{
        padding: .5rem;
        padding-left: 1rem;
        padding-right: 1rem;
        border: none;
        border-radius: .3rem;
        cursor: pointer;
        max-height: 2rem;
        background-color: lightblue;
    }
    .red{
        background-color: #dc2626;
    }
    .green{
        background-color: #22c55e;
    }
    buttons{
        display: flex;
        gap: 1rem;
    }
    .btn{
        padding: .5rem;
        padding-left: 1rem;
        padding-right: 1rem;
        border: none;
        border-radius: .3rem;
        cursor: pointer;
    }
    .red{
        background-color: #dc2626;
    }
    .green{
        background-color: #22c55e;
    }
</style>